# Landsat composite counterfactual audit -- manavgat_2021

- **Final status: supported_reduction**
- Canonical reproduction gate: **pass** (decisive gate: pipeline_semantic_reproduction, schema 2.0-pipeline-semantic)
- Raw GeoTIFF encoding differs (canonical serializes masked pixels as DN 0 with no nodata tag; diagnostic uses a -9999 sentinel) but is semantically equivalent after the production Step5 conversion; the raw files are NOT bitwise identical.
- The 5e-5 Celsius derived-reduction tolerance is a float32 NUMERICAL reproducibility tolerance, not a scientific effect-size threshold.
- QA masking actually applied: **QA_PIXEL** (QA_PIXEL cloud/shadow/snow/fill masking; QA_RADSAT not applied)
- Provenance state: **provenance_available** (verified source-boundary evidence: True; metadata-derived source-footprint/path-row boundary evidence, not pixel-level selected-scene provenance)

## Support-count boundary verdicts (current LST)

- `scene_count_edge`: **supported_reduction** (unit_type=raster_support_block, n_units=445, interval=[0.08927105754991421, 0.160965605606291])
- `unique_date_count_edge`: **supported_reduction** (unit_type=raster_support_block, n_units=443, interval=[0.060301181618752, 0.1309828529891139])
- `same_day_multiplicity_edge`: **supported_reduction** (unit_type=raster_support_block, n_units=172, interval=[0.480389321736553, 0.7297587621859789])
- `export_tile_boundary`: **unavailable** (unit_type=export_tile_partition_segment, n_units=None, interval=[None, None])
- `source_scene_path_row`: **supported_reduction** (unit_type=provenance_boundary_id, n_units=70, interval=[0.000634028763180897, 0.009957416146347271])

`reduction = absolute_jump_scene_weighted - absolute_jump_date_balanced` (positive => date-balanced compositing reduces the jump).

## Limitations

- `single_aoi_manavgat`: This is a single-AOI (manavgat_2021) Manavgat composite counterfactual; conclusions are specific to this AOI and window.
- `no_generalization`: The result does NOT establish generalization to other AOIs, regions, sensors, or time windows.
- `step8_model_impact_not_evaluated`: Downstream Step8 / model impact of the compositing change has NOT yet been evaluated; only seam/boundary behaviour was audited.
- `export_tile_control_unavailable`: The export-tile negative-control comparison is unavailable because the relevant products were direct exports or did not provide a comparable paired tile partition.
- `provenance_metadata_derived_not_pixel_level`: Provenance is metadata-derived source-footprint/path-row boundary evidence (valid geometric boundary evidence), NOT pixel-level selected-scene provenance; a median reducer has no semantically valid single selected-scene ID.
- `pathrow_reduction_small_or_uncertain`: Verified path/row-boundary reduction is very small for current_lst and current_minus_baseline and uncertain for anomaly_zscore.
- `supported_reduction_not_causal_proof`: A supported_reduction does NOT prove same-date duplication is the sole seam cause and does NOT automatically mandate a production reducer change.

## Claim boundary

A supported_reduction status is evidence that daily compositing lowers support-edge jumps in THIS AOI; it is NOT proof that same-date duplication is the sole cause, nor a mandate to change the canonical production reducer. Support-count-edge evidence is distinct from verified source-scene/path-row boundary evidence, and export-tile controls are a negative control only.
